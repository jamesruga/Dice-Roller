package sample;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

import javax.swing.*;
import java.beans.Visibility;
import java.net.URL;
import java.util.HashMap;
import java.util.Random;
import java.util.ResourceBundle;

public class Controller implements Initializable{

    HashMap<Integer,Integer> rounds=new HashMap<>();
    private DiceMeshViewer d;
    CategoryAxis xAxis = new CategoryAxis();
   NumberAxis yAxis = new NumberAxis();
    XYChart.Series series1 = new XYChart.Series();
    XYChart.Series series2 = new XYChart.Series();
    Random random=new Random();
    int faces=6;
    int max=6;
    int min=1;
    private BarChart<String,Number> chart;
    private ObservableList<XYChart.Data> dataD= FXCollections.observableArrayList();
    private ObservableList<XYChart.Data> dataP= FXCollections.observableArrayList();
    private int count=10000;
    private Task copyWorker;
    private int totalCountgone;
    private Timeline tl;
    private long waittime=1;
    @FXML
    private StackPane parentstack;

    @FXML
    private StackPane diceviewSt;

    @FXML
    private ProgressBar progressbar;

    @FXML
    private BorderPane diceview;

    @FXML
    private Button btAction;

    @FXML
    private BorderPane chartview;

    @FXML
    private Label chartTitle;

    @FXML
    private BorderPane setpane;

    @FXML
    private TextField throwsTxt;

    @FXML
    private TextField facesTxt;

    @FXML
    private Button setBt;

    @FXML
    private Button dicebt;

    @FXML
    private Button chartBt;

    @FXML
    private Label detailsbt;
    private int dices=2;

    @FXML
    void applyBtFaces(ActionEvent event) {
        faces=Integer.parseInt(facesTxt.getText());
        max=faces;
        JOptionPane.showMessageDialog(null,"No of faces set succesfully: "+faces);
    }

    @FXML
    void applyBtThrows(ActionEvent event) {
        dices=Integer.parseInt(throwsTxt.getText());
        JOptionPane.showMessageDialog(null,"No of dices set succesfully: "+dices);
    }




    @FXML
    void chartBtAction(ActionEvent event) {
        setpane.setVisible(false);
        diceview.setVisible(false);
        chartview.setVisible(true);
    }

    @FXML
    void diceBtAction(ActionEvent event) {
        setpane.setVisible(false);
        diceview.setVisible(true);
        chartview.setVisible(false);
    }

    @FXML
    void setBtAction(ActionEvent event) {
        setpane.setVisible(true);
        diceview.setVisible(false);
        chartview.setVisible(false);

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.err.println("dfghjkdfh");

        d=new DiceMeshViewer();
        Node node_dice=d.createMeshDice();

        d.animate();
        diceview.setCenter(node_dice);
        dice();
    }

    @FXML
    void btAction(ActionEvent event) {
        if(btAction.getText().equalsIgnoreCase("START")){
            d.animation.play();
            btAction.setText("STOP");
            startRandomizer();
            btAction.setStyle("-fx-background-color: red");
        }else{
            copyWorker.cancel(true);
            progressbar.progressProperty().unbind();
            progressbar.setProgress(0);
            d.animation.stop();
            totalCountgone=count;
            btAction.setText("START");
            btAction.setStyle("-fx-background-color: green");

        }
    }

    void dice(){
        chart=new BarChart<String,Number>(xAxis,yAxis);
        xAxis.setLabel("Outcomes");
        yAxis.setLabel("Occurences");
        chartview.setCenter(chart);

        series1.setData(dataD);
        series1.setName("No. of Occurence");
        series2.setData(dataP);
        series2.setName("Percentage");
//        series1.getData().add(new XYChart.Data("1",781));
//        series1.getData().add(new XYChart.Data("2",12));
//        series1.getData().add(new XYChart.Data("3",45));
//        series1.getData().add(new XYChart.Data("4",22));
//        series1.getData().add(new XYChart.Data("5",120));
//        series1.getData().add(new XYChart.Data("6",42));
        tl = new Timeline();
        tl.getKeyFrames().add(new KeyFrame(Duration.millis(500),
                new EventHandler<ActionEvent>() {
                    @Override public void handle(ActionEvent actionEvent) {
                        for (XYChart.Series<String,Number> series : chart.getData()) {
                            for (XYChart.Data<String,Number> data : series.getData()) {
                                data.setYValue(Math.random() * 100);
                            }
                        }
                    }
                }));
//        tl.setCycleCount(3);
        tl.play();

        chart.getData().addAll(series1,series2);

    }

void startRandomizer(){
    dices=Integer.parseInt(throwsTxt.getText());
    faces=Integer.parseInt(facesTxt.getText());
    max=faces;

    max=dices*faces;
    faces=max;

    progressbar.setProgress(0);
    copyWorker = createWorker();

    progressbar.progressProperty().unbind();
    progressbar.progressProperty().bind(copyWorker.progressProperty());

    copyWorker.messageProperty().addListener(new ChangeListener<String>() {
        public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
            int a=Integer.parseInt(newValue)-1;
            StringBuffer bf=new StringBuffer();
            if(!rounds.containsKey(a)){

                rounds.put(a,1);
            }else {
                int pr = rounds.get(a);
                rounds.put(a,pr+1);
            }


            for(int k=1;k<=faces;k++){
               int r= rounds.get(k-1);
                dataD.add(new XYChart.Data((k)+"",r));
                double aa=r;
                double bb=count;
                dataP.add(new XYChart.Data((k)+"",(aa/bb)*100));
                bf.append("Face "+k+"={"+r+" ROUNDS} , percentage ["+((aa/bb)*100)+"]\n");
            }

            detailsbt.setText(bf.toString());
            chartTitle.setText("Statistics for "+count+" Occurences of "+dices+" dices with "+(faces/6)+" faces each");

        }
    });

    new Thread(copyWorker).start();

}
    public Task createWorker() {
        return new Task() {
            @Override
            protected Object call() throws Exception {
                for (int i = 0; i < count; i++) {
                    Thread.sleep(waittime);
                    int p = random.nextInt(max - min + 1) + min;
//                    System.out.println(p + "");
                    updateMessage(p+"");
                    updateProgress(i + 1, count);
                }

                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        d.animation.stop();
                        btAction.setText("START");
                        btAction.setStyle("-fx-background-color: green");
                    }
                });

                return true;
            }
        };
    }

}
