package sample;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import javax.swing.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main extends Application {


    private int c;

    @Override
    public void start(Stage primaryStage) throws Exception{

        javafx.geometry.Rectangle2D d= Screen.getPrimary().getVisualBounds();
        FXMLLoader loader= new FXMLLoader(getClass().getResource("main.fxml"));
        loader.setController(new Controller());
        Parent root = loader.load();
        primaryStage.setTitle("Dice Throw");
        primaryStage.setScene(new Scene(root));
        primaryStage.setHeight(d.getHeight());
        primaryStage.setWidth(d.getWidth());
        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we) {
                System.exit(3);
            }
        });

//        String ff=JOptionPane.showInputDialog(null,"Enter Serial No","",JOptionPane.OK_CANCEL_OPTION);
//
//        if(ff.equalsIgnoreCase("SUPER")) {

//        }else if(ff.equalsIgnoreCase("test")){
//            new Thread(new Task() {
//                @Override
//                protected Object call() throws Exception {
//                    int now=Integer.parseInt(new SimpleDateFormat("hhmmssSSS").format(new Date()));
//                    if(c==0) {
//                        c=Integer.parseInt(new SimpleDateFormat("hhmmssSSS").format(new Date()));
//                        JOptionPane.showMessageDialog(null,"Time allocated: 1 min. End time: "+new SimpleDateFormat("hh:mm:ss").format((new SimpleDateFormat("hhmmssSSS").parse(c+""))));
//                    }else if((c+100000)<=now) {
//                        System.exit(3);
//                    }
//
//                    return true;
//                }
//            }).start();
//        }else {
//            System.exit(3);
//        }
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
